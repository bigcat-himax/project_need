#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#ifdef TRUSTZONE_SEC
#ifdef FREERTOS
/* Trustzone config. */
//#include "partition_ARMCM55.h"
/* FreeRTOS includes. */
//#include "secure_port_macros.h"
#else
#if (__ARM_FEATURE_CMSE & 1) == 0
#error "Need ARMv8-M security extensions"
#elif (__ARM_FEATURE_CMSE & 2) == 0
#error "Compile with --cmse"
#endif
#include "arm_cmse.h"
//#include "veneer_table.h"
//#include "partition_ARMCM55.h"
#endif
#endif

#include "WE2_device.h"
#include "board.h"
#include "xprintf.h"
#include "WE2_core.h"
#include "board.h"
#include "hx_drv_scu.h"
#include "hx_drv_swreg_aon.h"
#ifdef IP_gpio
#include "hx_drv_gpio.h"
#endif
#include "hx_drv_pmu_export.h"
#include "hx_drv_pmu.h"
#include "BITOPS.h"
#include "i2cm_int.h"
#include "hx_drv_timer.h"
#include "hx_drv_iic.h"


static HX_DRV_DEV_IIC_PTR dev_iic[USE_DW_IIC_ALL];

static void i2cm0_callback_fun_tx(void *status);
static void i2cm0_callback_fun_rx(void *status);
static void i2cm0_callback_fun_err(void *status);

static void i2cm1_callback_fun_tx(void *status);
static void i2cm1_callback_fun_rx(void *status);
static void i2cm1_callback_fun_err(void *status);

static void for_hx_drv_i2cm1_tx_cb(void *status);

/*******************************************************************************
 * Code
 ******************************************************************************/
static void i2cm0_callback_fun_tx(void *status)
{
    xprintf("I2C Master0 TX CB_FUN\n");
}

static void i2cm0_callback_fun_rx(void *status)
{
    xprintf("I2C Master0 RX CB_FUN\n");
}

static void i2cm0_callback_fun_err(void *status)
{
    HX_DRV_DEV_IIC *iic_obj = status;
    HX_DRV_DEV_IIC_INFO *iic_info_ptr = &(iic_obj->iic_info);

    xprintf("I2C Master0 ERR CB_FUN\n");
    xprintf("err_state:%d\n", iic_info_ptr->err_state);
}

static void i2cm1_callback_fun_tx(void *status)
{
    xprintf("I2C Master1 TX CB_FUN\n");
}

static void i2cm1_callback_fun_rx(void *status)
{
    xprintf("I2C Master1 RX CB_FUN\n");
}

static void i2cm1_callback_fun_err(void *status)
{
    HX_DRV_DEV_IIC *iic_obj = status;
    HX_DRV_DEV_IIC_INFO *iic_info_ptr = &(iic_obj->iic_info);

    xprintf("I2C Master1 ERR CB_FUN\n");
    xprintf("err_state:%d\n", iic_info_ptr->err_state);
}

static void for_hx_drv_i2cm1_tx_cb(void *status)
{
    xprintf("%s:%d\n",__FUNCTION__,__LINE__);
}

/*!
 * @brief Main function
 */
int app_main(void) {
    uint8_t regAddr[5] = {0x39,0,0,0,0};
    uint8_t regLen = 1;
    uint8_t ruffer[5] = {0,0,0,0,0};
    uint8_t dataLen = 1;
    int32_t e_no = E_OK;

	printf("Hello from secure world! Only Secure - i2cm_int\r\n");

    //i2c master initial 
	hx_drv_i2cm_init(USE_DW_IIC_0, HX_I2C_HOST_MST_0_BASE, DW_IIC_SPEED_STANDARD);
	hx_drv_i2cm_init(USE_DW_IIC_1, HX_I2C_HOST_MST_1_BASE, DW_IIC_SPEED_STANDARD);

    //get i2c master device pointer
    dev_iic[USE_DW_IIC_0] = hx_drv_i2cm_get_dev(USE_DW_IIC_0);
    dev_iic[USE_DW_IIC_1] = hx_drv_i2cm_get_dev(USE_DW_IIC_1);

    //set i2c master device with tx/rx/err callback
    e_no = dev_iic[USE_DW_IIC_0]->iic_control(DW_IIC_CMD_SET_TXCB, i2cm0_callback_fun_tx);
    e_no = dev_iic[USE_DW_IIC_0]->iic_control(DW_IIC_CMD_SET_RXCB, i2cm0_callback_fun_rx);
    e_no = dev_iic[USE_DW_IIC_0]->iic_control(DW_IIC_CMD_SET_ERRCB, i2cm0_callback_fun_err);

    e_no = dev_iic[USE_DW_IIC_1]->iic_control(DW_IIC_CMD_SET_TXCB, i2cm1_callback_fun_tx);
    e_no = dev_iic[USE_DW_IIC_1]->iic_control(DW_IIC_CMD_SET_RXCB, i2cm1_callback_fun_rx);
    e_no = dev_iic[USE_DW_IIC_1]->iic_control(DW_IIC_CMD_SET_ERRCB, i2cm1_callback_fun_err);

    //set pin mux to i2c master 
    xprintf("I2C Master 0 Mux to PDM_CLK_DATA0 \n");
    xprintf("    IIC_HOST_PIN_MUX_PB9 - SCL \n");
    xprintf("    IIC_HOST_PIN_MUX_PB10 - SDA \n");
    xprintf("I2C Master 1 Mux to image sensor ctrl\n");
    hx_drv_scu_set_PB9_pinmux(SCU_PB9_PINMUX_I2C_M_SCL);
    hx_drv_scu_set_PB10_pinmux(SCU_PB10_PINMUX_I2C_M_SDA);
    hx_drv_scu_set_SEN_I2C_MST_SDA_pinmux(SCU_SEN_I2CM_SDA_PINMUX_I2CM_SDA_0);
    hx_drv_scu_set_SEN_I2C_MST_SCL_pinmux(SCU_SEN_I2CM_SCL_PINMUX_I2CM_SCL_0);

    //test i2c master 1 interrupt write case
    regAddr[0] = 0x39;
    regLen = 1;
    ruffer[0] = 0x0;
    dataLen = 1;

    printf("[I2C]id 0x30, write 0x39:\r\n");
    //interrupt write is non-blocking API, we add a while loop to check later callback happen 
    hx_drv_i2cm_interrupt_write(USE_DW_IIC_1, 0x30, regAddr, regLen, for_hx_drv_i2cm1_tx_cb);
	
    while(1)
        ;
	

    return 0;
}
