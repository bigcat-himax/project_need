/*
 * i2cm_int.h
 *
 *  Created on: Aug 21, 2023
 *      Author: 902449
 */

#ifndef SCENARIO_APP_I2CM_INT_
#define SCENARIO_APP_I2CM_INT_

int app_main(void);

#endif /* SCENARIO_APP_I2CM_INT_ */
